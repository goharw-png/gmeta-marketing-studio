GMETA MARKETING STUDIO - WINDOWS 11 STARTER
===========================================

WHAT IT DOES
- Upload one product image and enter product details.
- Select English, Chinese, French or German.
- Creates a vertical 9:16 MP4 with a product poster and spoken narration.
- Generates a caption and hashtags.
- Uses local Ollama for AI-written copy if installed; otherwise uses safe built-in templates.

FIRST RUN
1. Extract this ZIP to a folder such as Desktop\GMeta_Marketing_Studio.
2. Install Python 3.11 or newer from https://www.python.org/downloads/
   During installation, enable "Add Python to PATH".
3. Double-click START_GMETA.bat. The first run installs Python packages.
4. Wait until it says Running on http://127.0.0.1:5000
5. Open Microsoft Edge or Chrome and visit http://127.0.0.1:5000

OPTIONAL LOCAL AI (RECOMMENDED)
1. Install Ollama from https://ollama.com/download
2. Double-click SETUP_OLLAMA.bat and wait for qwen2.5:3b to download.
3. Restart GMeta by closing its window and double-clicking START_GMETA.bat.
The app sends prompts only to your local Ollama service for script generation.
The voice generation uses Microsoft Edge TTS service and therefore needs internet.

IMPORTANT
- This is a working starter app, not a finished commercial SaaS product.
- The first version makes a simple image-based narrated promo video. It does not
  yet generate AI product footage, remove image backgrounds, or publish directly
  to social platforms.
- Always check product claims, translations, voice pronunciation and platform rules.
- Do not upload confidential or private product/customer information.
- Generated MP4 files are saved in the outputs folder.
- The app is local-only at 127.0.0.1 and is not publicly hosted.
- If Windows blocks scripts, run the .bat file normally; do not change security settings.
- If the app reports FFmpeg problems, imageio-ffmpeg should provide a bundled FFmpeg.


FREE PUBLIC DEPLOYMENT (RENDER)
1. Create a GitHub repository and upload the extracted project files.
2. In Render, create a New Web Service and connect that repository.
3. Build command: pip install -r requirements.txt
4. Start command: gunicorn app:app
5. Choose the Free instance and deploy.
6. Your public URL will be shown in the Render dashboard.

CLOUD DEMO LIMITATIONS
- Free Render services sleep after 15 minutes without traffic and may take about
  a minute to wake up.
- Local uploads and generated videos are temporary and can disappear when the
  service sleeps, restarts, or redeploys. Do not use it as permanent file storage.
- The app is a prototype. Test with non-sensitive sample product images only.
- Ollama installed on your Windows computer is NOT available to the public cloud
  service at 127.0.0.1. In the cloud, AI copy falls back to built-in templates
  unless a separately hosted model/API is configured.
- The app does not publish directly to social platforms.
