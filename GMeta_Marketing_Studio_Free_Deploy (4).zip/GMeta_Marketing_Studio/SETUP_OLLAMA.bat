@echo off
echo This optional step uses a local Ollama model for better multilingual marketing copy.
where ollama >nul 2>nul
if errorlevel 1 (
  echo Ollama was not found. Install it from https://ollama.com/download
  pause
  exit /b
)
ollama pull qwen2.5:3b
pause
