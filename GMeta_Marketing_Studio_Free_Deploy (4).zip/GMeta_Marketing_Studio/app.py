import os, json, re, uuid, subprocess, shutil
from pathlib import Path
from flask import Flask, request, render_template, send_from_directory, flash, redirect, url_for
from werkzeug.utils import secure_filename
import requests
import edge_tts
import asyncio
from PIL import Image, ImageOps, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
UPLOADS = ROOT / "uploads"
OUTPUTS = ROOT / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = "change-this-local-demo-secret"
app.config["MAX_CONTENT_LENGTH"] = 15 * 1024 * 1024

LANGUAGES = {
    "English": {"voice": "en-US-AriaNeural", "code": "en"},
    "Chinese": {"voice": "zh-CN-XiaoxiaoNeural", "code": "zh"},
    "French": {"voice": "fr-FR-DeniseNeural", "code": "fr"},
    "German": {"voice": "de-DE-KatjaNeural", "code": "de"},
}
ALLOWED = {".png", ".jpg", ".jpeg", ".webp"}

def ask_ollama(product, benefits, audience, language, platform):
    prompt = f"""
Create a short, truthful social-media product promotion in {language}.
Product: {product}
Features/benefits supplied by user: {benefits}
Audience: {audience or 'general audience'}
Platform: {platform}
Return ONLY valid JSON with keys:
title (short), narration (45-65 words), caption (short), hashtags (array of 5).
Rules: Do not invent product specifications, prices, guarantees, certifications or results.
If details are missing, use neutral wording. Make the language natural for {language}.
"""
    try:
        r = requests.post(
            "http://127.0.0.1:11434/api/generate",
            json={"model": os.getenv("OLLAMA_MODEL", "qwen2.5:3b"),
                  "prompt": prompt, "stream": False, "format": "json"},
            timeout=180
        )
        r.raise_for_status()
        raw = r.json().get("response", "{}")
        data = json.loads(raw)
        if not all(k in data for k in ("title", "narration", "caption", "hashtags")):
            raise ValueError("Incomplete AI response")
        return data, "Ollama"
    except Exception:
        fallback = {
            "English": ("Discover something useful", f"Meet {product}. {benefits or 'A product worth discovering.'} Take a closer look and see whether it fits your needs. Explore the details and make an informed choice.", "Take a closer look at this product.", ["#ProductSpotlight", "#Discover", "#Shopping", "#NewFind", "#SocialMedia"]),
            "Chinese": ("发现实用好物", f"来认识一下{product}。{benefits or '这是一款值得了解的产品。'}了解更多信息，看看它是否适合你的需求。", "了解这款产品的更多信息。", ["#好物推荐", "#产品介绍", "#发现好物", "#分享", "#购物"]),
            "French": ("Découvrez un produit utile", f"Découvrez {product}. {benefits or 'Un produit qui mérite votre attention.'} Consultez les détails pour voir s’il correspond à vos besoins et faites un choix éclairé.", "Découvrez les détails de ce produit.", ["#Produit", "#Découverte", "#Shopping", "#Présentation", "#ÀDécouvrir"]),
            "German": ("Entdecken Sie ein praktisches Produkt", f"Lernen Sie {product} kennen. {benefits or 'Ein Produkt, das einen genaueren Blick wert ist.'} Sehen Sie sich die Details an und prüfen Sie, ob es zu Ihren Bedürfnissen passt.", "Entdecken Sie die Produktdetails.", ["#Produkt", "#Entdecken", "#Shopping", "#Produktvorstellung", "#Neu"]),
        }
        title, narration, caption, hashtags = fallback[language]
        return {"title": title, "narration": narration, "caption": caption, "hashtags": hashtags}, "Built-in template (Ollama not connected)"

def find_font(size):
    candidates = [
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/msyh.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    ]
    for p in candidates:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, size)
            except Exception: pass
    return ImageFont.load_default()

def make_poster(image_path, title, caption, out_path):
    W, H = 1080, 1920
    im = Image.open(image_path).convert("RGB")
    im = ImageOps.fit(im, (W, H), method=Image.Resampling.LANCZOS)
    overlay = Image.new("RGBA", (W, H), (0,0,0,0))
    d = ImageDraw.Draw(overlay)
    # Dark translucent text panels improve legibility.
    d.rounded_rectangle((55, 110, 1025, 430), radius=34, fill=(0,0,0,165))
    d.rounded_rectangle((55, 1510, 1025, 1810), radius=34, fill=(0,0,0,165))
    f1, f2 = find_font(64), find_font(42)
    def wrap(text, font, max_width):
        words, lines, line = text.split(), [], ""
        for word in words:
            test = (line + " " + word).strip()
            if d.textbbox((0,0), test, font=font)[2] <= max_width:
                line = test
            else:
                if line: lines.append(line)
                line = word
        if line: lines.append(line)
        return lines[:3]
    y = 165
    for line in wrap(title, f1, 880):
        d.text((95,y), line, font=f1, fill="white", stroke_width=1, stroke_fill="black")
        y += 82
    y = 1570
    for line in wrap(caption, f2, 880):
        d.text((95,y), line, font=f2, fill="white", stroke_width=1, stroke_fill="black")
        y += 58
    Image.alpha_composite(im.convert("RGBA"), overlay).convert("RGB").save(out_path, quality=94)

async def make_voice(text, voice, out_file):
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(str(out_file))

def render_video(poster, audio, output):
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        # imageio-ffmpeg package supplies a bundled executable.
        try:
            import imageio_ffmpeg
            ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            raise RuntimeError("FFmpeg is unavailable. Install the requirements and run setup again.")
    cmd = [ffmpeg, "-y", "-loop", "1", "-i", str(poster), "-i", str(audio),
           "-vf", "scale=1080:1920,format=yuv420p",
           "-c:v", "libx264", "-tune", "stillimage", "-c:a", "aac",
           "-b:a", "160k", "-shortest", "-movflags", "+faststart", str(output)]
    subprocess.run(cmd, check=True, capture_output=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        product = request.form.get("product", "").strip()
        benefits = request.form.get("benefits", "").strip()
        audience = request.form.get("audience", "").strip()
        language = request.form.get("language", "English")
        platform = request.form.get("platform", "Instagram Reels")
        file = request.files.get("product_image")
        if not product or not file or not file.filename:
            flash("Enter a product name and choose one product image.")
            return redirect(url_for("index"))
        if language not in LANGUAGES:
            flash("Please choose a supported language.")
            return redirect(url_for("index"))
        ext = Path(secure_filename(file.filename)).suffix.lower()
        if ext not in ALLOWED:
            flash("Use a PNG, JPG, JPEG or WEBP product image.")
            return redirect(url_for("index"))
        job = uuid.uuid4().hex[:10]
        source = UPLOADS / f"{job}{ext}"
        file.save(source)
        try:
            content, engine = ask_ollama(product, benefits, audience, language, platform)
            poster = OUTPUTS / f"{job}_poster.jpg"
            audio = OUTPUTS / f"{job}_voice.mp3"
            video = OUTPUTS / f"{job}.mp4"
            make_poster(source, content["title"], content["caption"], poster)
            asyncio.run(make_voice(content["narration"], LANGUAGES[language]["voice"], audio))
            render_video(poster, audio, video)
            return render_template("result.html", content=content, engine=engine,
                                   language=language, platform=platform, video=f"{job}.mp4")
        except Exception as e:
            flash(f"Could not create the video: {e}")
            return redirect(url_for("index"))
    return render_template("index.html", languages=list(LANGUAGES.keys()))

@app.route("/videos/<path:filename>")
def videos(filename):
    return send_from_directory(OUTPUTS, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
